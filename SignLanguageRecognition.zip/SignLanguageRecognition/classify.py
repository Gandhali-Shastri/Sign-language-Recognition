from sklearn import svm
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB as nb
from sklearn.neighbors import KNeighborsClassifier as knn
from sklearn.linear_model import LogisticRegression as lr
import numpy as np


def run_svm(X_train, X_test,y_train, y_test):
	svclassifier = SVC(kernel='linear')
	svclassifier.fit(X_train, y_train)
	pred=svclassifier.predict(X_test)
	# print(pred)
	np.savetxt('output_svm.csv', np.c_[range(1,len(X_test)+1),pred,y_test], delimiter=',', header = 'ImageId,Label,TrueLabel', comments = '', fmt='%d')
	return pred

def run_lr(x, x_,y, y_test):
	clf = lr()
	print("lr started")
	clf.fit(x,y)
	pred=clf.predict(x_)
	#print(pred)
	np.savetxt('output_lr.csv', np.c_[range(1,len(x_)+1),pred,y_test], delimiter=',', header = 'ImageId,Label,TrueLabel', comments = '', fmt='%d')
	return pred


def run_nb(x, x_,y, y_test):
	clf = nb()
	print("nb started")
	clf.fit(x,y)
	pred=clf.predict(x_)
	#print(pred)
	np.savetxt('output_nb.csv', np.c_[range(1,len(x_)+1),pred,y_test], delimiter=',', header = 'ImageId,Label,TrueLabel', comments = '', fmt='%d')
	return  pred


def run_knn(x, x_,y, y_test):
	clf=knn(n_neighbors=3)
	print("knn started")
	clf.fit(x,y)
	pred=clf.predict(x_)
	#print(pred)
	np.savetxt('output_knn.csv', np.c_[range(1,len(x_)+1),pred,y_test], delimiter=',', header = 'ImageId,Label,TrueLabel', comments = '', fmt='%d')
	return pred
