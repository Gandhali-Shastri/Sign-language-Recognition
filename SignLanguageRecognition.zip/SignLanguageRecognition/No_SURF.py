from sklearn.metrics import classification_report, confusion_matrix
import numpy as np
import cv2
import os
import csv
from classify import run_svm, run_knn,run_nb,run_lr
import pandas as pd
import sklearn.metrics as sm
from sklearn.model_selection import train_test_split

outputLine = []
flattened_sign_image= []


def preprocessing_without_surf(path):
    a = []
    for i in range(9216):
        a.append("label" + str(i))

    with open('data.csv', 'w') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=a)
        writer.writeheader()
    label = 0

    with open('data.csv', 'a') as csvfile:
        spamwriter = csv.writer(csvfile)
        for (dirpath, dirnames, filenames) in os.walk(path):
            for dirname in dirnames:
                print(dirname)
                for (direcpath, direcnames, files) in os.walk(path + "\\" + dirname):
                    for file in files:
                        actual_path = path + "\\\\" + dirname + "\\\\" + file
                        print(actual_path)
                        bw_image = process_images(actual_path)
                        flattened_sign_image = bw_image.flatten()
                        outputLine = [label] + np.array(flattened_sign_image).tolist()
                        spamwriter.writerow(outputLine)
                label = label + 1


def process_images(path):
    frame = cv2.imread(path)
    frame = cv2.resize(frame,(96,96))
    #cv2.imshow("original",frame)

    converted = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    #print(frame.shape)

    lowerBoundary = np.array([0,40,30],dtype="uint8")
    upperBoundary = np.array([43,255,254],dtype="uint8")

    skinMask = cv2.inRange(converted, lowerBoundary, upperBoundary)

    # apply a series of erosions and dilations to the mask using an elliptical kernel
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    skinMask = cv2.erode(skinMask, kernel, iterations = 2)
    skinMask = cv2.dilate(skinMask, kernel, iterations = 2)

    lowerBoundary = np.array([170,80,30],dtype="uint8")
    upperBoundary = np.array([180,255,250],dtype="uint8")

    skinMask2 = cv2.inRange(converted, lowerBoundary, upperBoundary)
    skinMask = cv2.addWeighted(skinMask,0.5,skinMask2,0.5,0.0)
    #print(skinMask.flatten())
    #print(skinMask.shape)

    skinMask = cv2.medianBlur(skinMask, 5)
    skin = cv2.bitwise_and(frame, frame, mask = skinMask)
    frame = cv2.addWeighted(frame,1.5,skin,-0.5,0)
    skin = cv2.bitwise_and(frame, frame, mask = skinMask)

    #cv2.imshow("masked",skin)

    h,w = skin.shape[:2]
    bw_image = cv2.cvtColor(skin, cv2.COLOR_HSV2BGR)
    bw_image = cv2.cvtColor(skin, cv2.COLOR_BGR2GRAY)
    bw_image = cv2.GaussianBlur(bw_image,(5,5),0)
    threshold = 1
    for i in range(h):
        for j in range(w):
            if bw_image[i][j] > threshold:
               bw_image[i][j] = 0
            else:
               bw_image[i][j] = 255

    #cv2.imshow("thresholded",bw_image)
    #cv2.waitKey(0)
    # cv2.destroyAllWindows()
    return bw_image


def calc_accuracy(method,label_test,pred):
    print("Accuracy for ",method,sm.accuracy_score(label_test,pred))
    # print("Precision for ",method,sm.precision_score(label_test,pred,average='micro'))

#comment this
# preprocessing_without_surf("dataset")

data = pd.read_csv("data.csv")
# print(data.head())

X = np.array(data)
y = np.array(data.index)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.40,random_state=42)
# print(y_test)

pred = run_svm(X_train, X_test,y_train, y_test)

print(confusion_matrix(y_test,pred))
print(classification_report(y_test,pred))
calc_accuracy("SVM",y_test,pred)

predknn = run_knn(X_train, X_test,y_train, y_test)
print(confusion_matrix(y_test,predknn))
print(classification_report(y_test,predknn))
calc_accuracy("SVM",y_test,pred)

predlr = run_lr(X_train, X_test,y_train, y_test)
print(confusion_matrix(y_test,predlr))
print(classification_report(y_test,predlr))
calc_accuracy("SVM",y_test,pred)

predlr1 = run_nb(X_train, X_test,y_train, y_test)
print(confusion_matrix(y_test,predlr1))
print(classification_report(y_test,predlr1))
calc_accuracy("SVM",y_test,pred)