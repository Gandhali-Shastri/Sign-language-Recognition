import cv2
import os
from sklearn.cluster import MiniBatchKMeans
import numpy as np
from classify_surf import train_test_val_split_idxs, cluster_features, \
    perform_data_split, predict_knn, predict_svm, predict_lr, predict_nb

img_descs = []
y = []
path = "dataset"


def preprocessing_surf(path):
    # initialise
    label = 0

    # creating desc for each file with label
    for (dirpath, dirnames, filenames) in os.walk(path):
        for dirname in dirnames:
            print(dirname)
            for (direcpath, direcnames, files) in os.walk(path + "\\" + dirname):
                for file in files:
                    actual_path = path + "\\\\" + dirname + "\\\\" + file
                    print(actual_path)
                    des = process_images_surf(actual_path)
                    img_descs.append(des)
                    y.append(label)
            label = label + 1


def process_images_surf(path):
    frame = cv2.imread(path)
    frame = cv2.resize(frame, (128, 128))
    converted2 = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    converted = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)  # Convert from RGB to HSV
    # cv2.imshow("original",converted2)

    lowerBoundary = np.array([0, 40, 30], dtype="uint8")
    upperBoundary = np.array([43, 255, 254], dtype="uint8")
    skinMask = cv2.inRange(converted, lowerBoundary, upperBoundary)
    skinMask = cv2.addWeighted(skinMask, 0.5, skinMask, 0.5, 0.0)
    # cv2.imshow("masked",skinMask)

    skinMask = cv2.medianBlur(skinMask, 5)

    skin = cv2.bitwise_and(converted2, converted2, mask=skinMask)
    # frame = cv2.addWeighted(frame,1.5,skin,-0.5,0)
    # skin = cv2.bitwise_and(frame, frame, mask = skinMask)

    # skinGray=cv2.cvtColor(skin, cv2.COLOR_BGR2GRAY)

    # cv2.imshow("masked2",skin)
    img2 = cv2.Canny(skin, 60, 60)
    # cv2.imshow("edge detection",img2)

    surf = cv2.xfeatures2d.SURF_create()
    # surf.extended=True
    img2 = cv2.resize(img2, (256, 256))
    kp, des = surf.detectAndCompute(img2, None)
    print(len(des))
    img2 = cv2.drawKeypoints(img2, kp, None, (0, 0, 255), 4)
    # plt.imshow(img2),plt.show()

    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    # print(len(des))
    return des

#comment this
# preprocessing_surf("dataset")
y=np.array(y)
# print(len(img_descs))
training_idxs, test_idxs, val_idxs = train_test_val_split_idxs(len(img_descs), 0.4, 0.0)

#creating histogram using kmeans minibatch cluster model
X, cluster_model = cluster_features(img_descs, training_idxs, MiniBatchKMeans(n_clusters=150))

#splitting data into test, train, validate using the indexes
X_train, X_test, X_val, y_train, y_test, y_val = perform_data_split(X, y, training_idxs, test_idxs, val_idxs)

#using classification methods
predict_knn(X_train, X_test,y_train, y_test)
predict_svm(X_train, X_test,y_train, y_test)
predict_lr(X_train, X_test,y_train, y_test)
predict_nb(X_train, X_test,y_train, y_test)
